package com.diploma.project.repository;

import com.diploma.project.model.Plan;
import com.diploma.project.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PlanRepository extends JpaRepository<Plan, Long> {

    //User findByUsername(String username);
    //
    // Plan findByCourse_id(int course_id);
    //List<Plan> findByCourse_id(int course_id);
}
