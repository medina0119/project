package com.diploma.project.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Map;

@Controller
public class TeachingController {
    @GetMapping("/teaching/main")
    public String teaching(Map<String, Object> model) {
        return "teaching/teaching-main";
    }
}
