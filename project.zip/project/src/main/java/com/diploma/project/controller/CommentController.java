package com.diploma.project.controller;

import com.diploma.project.model.Comment;
import com.diploma.project.model.Message;
import com.diploma.project.model.User;
import com.diploma.project.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@Controller
public class CommentController {

    @Autowired
    private CommentRepository commentRepository;

    @PostMapping("/comment/add")
    public String add(
            @AuthenticationPrincipal User user,
            @RequestParam int plan_id,
            @RequestParam String title,
            @RequestParam String text, Map<String, Object> model
    ) {
        Comment comment = new Comment(plan_id, title, text, user);
        commentRepository.save(comment);
        Iterable<Comment> comments = commentRepository.findAll();
        model.put("comments", comments);

        return "redirect:/plan/" + plan_id;
    }
}
