package com.diploma.project.controller;


import com.diploma.project.model.News;
import com.diploma.project.repository.NewsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Optional;

@Controller
public class NewsController {

    @Autowired
    private NewsRepository newsRepository;

    @GetMapping("/news")
    public String news(Model model){
        Iterable<News> news = newsRepository.findAll();
        model.addAttribute("news", news);
        return "news-main";
    }

    @GetMapping("/news/add")
    public String newsAdd(Model model){
        return "news-add";
    }

    @PostMapping("/news/add")
    public String newsAddPost(@RequestParam String title, @RequestParam String anons, @RequestParam String description, Model model){
        News news = new News(title, anons, description);
        newsRepository.save(news);
        return "redirect:/news";
    }

    @GetMapping("/news/{id}")
    public String newsDetails(@PathVariable(value="id") long id, Model model){
        if(!newsRepository.existsById(id)){
            return "redirect:/news";
        }
        Optional<News> news = newsRepository.findById(id);
        ArrayList<News> newsArr = new ArrayList<>();
        news.ifPresent(newsArr::add);
        model.addAttribute("newsArr", newsArr);
        return "news-details";
    }

    @GetMapping("/news/{id}/edit")
    public String newsEdit(@PathVariable(value="id") long id, Model model){
        if(!newsRepository.existsById(id)){
            return "redirect:/news";
        }
        Optional<News> news = newsRepository.findById(id);
        ArrayList<News> newsArr = new ArrayList<>();
        news.ifPresent(newsArr::add);
        model.addAttribute("newsArr", newsArr);
        return "news-edit";
    }

    @PostMapping("/news/{id}/edit")
    public String newsUpdatePost(@PathVariable(value="id") long id, @RequestParam String title, @RequestParam String anons, @RequestParam String description, Model model){
        News news = newsRepository.findById(id).orElseThrow();
        news.setTitle(title);
        news.setAnons(anons);
        news.setDescription(description);
        newsRepository.save(news);

        return "redirect:/news";
    }

    @PostMapping("/news/{id}/remove")
    public String newsDeletePost(@PathVariable(value="id") long id, Model model){
        News news = newsRepository.findById(id).orElseThrow();
        newsRepository.delete(news);

        return "redirect:/news";
    }
}
