package com.diploma.project.controller;

import com.diploma.project.model.Speciality;
import com.diploma.project.repository.SpecialityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class RoadmapController {

    @Autowired
    SpecialityRepository specialityRepository;

    @GetMapping("/roadmap")
    public String roadmap(Model model) {
        List<Speciality> specialities = (List<Speciality>) specialityRepository.findAll();
        ArrayList<Speciality> specArr = new ArrayList<>();
        for (int i = 0; i < specialities.size(); i++){
            Speciality speciality = specialities.get(i);
            if (speciality.getSphere_id() == 0){
                specArr.add(speciality);
            }
        }
        model.addAttribute("specArr", specArr);
        return "page/roadmap";
    }

    @GetMapping("/roadmap/{id}")
    public String roadmapDetails(@PathVariable(value="id") long id, Model model){
        if(!specialityRepository.existsById(id)){
            return "redirect:/roadmap";
        }
        List<Speciality> specialities = (List<Speciality>) specialityRepository.findAll();
        ArrayList<Speciality> specArr = new ArrayList<>();
        for (int i = 0; i < specialities.size(); i++){
            Speciality speciality = specialities.get(i);
            if (speciality.getId() == id){
                specArr.add(speciality);
            }
        }
        model.addAttribute("specArr", specArr);

        List<Speciality> specTest = (List<Speciality>) specialityRepository.findAll();
        ArrayList<Speciality> specDetArr = new ArrayList<>();
        for (int i = 0; i < specTest.size(); i++){
            Speciality speciality = specTest.get(i);
            if (speciality.getSphere_id() == id){
                specDetArr.add(speciality);
            }
        }

        model.addAttribute("specDetArr", specDetArr);
        return "page/roadmap-details";
    }

    @GetMapping("/roadmap2/{id}")
    public String roadmapDetails2(@PathVariable(value="id") long id, Model model){
        if(!specialityRepository.existsById(id)){
            return "redirect:/roadmap";
        }
        Optional<Speciality> spCheck = specialityRepository.findById(id);
        Speciality s = new Speciality(spCheck.get().getName(), spCheck.get().getDescription(), spCheck.get().getSphere_id(), spCheck.get().getLevel());
        if (spCheck.get().getLevel() == 3){
            model.addAttribute("spCheck", s);
            return "page/roadmap-block";
        }

        List<Speciality> specialities = (List<Speciality>) specialityRepository.findAll();
        ArrayList<Speciality> specArr = new ArrayList<>();
        for (int i = 0; i < specialities.size(); i++){
            Speciality speciality = specialities.get(i);
            if (speciality.getId() == id){
                specArr.add(speciality);
            }
        }
        model.addAttribute("specArr", specArr);

        List<Speciality> specTest = (List<Speciality>) specialityRepository.findAll();
        ArrayList<Speciality> specDetArr = new ArrayList<>();
        for (int i = 0; i < specTest.size(); i++){
            Speciality speciality = specTest.get(i);
            if (speciality.getSphere_id() == id){
                specDetArr.add(speciality);
            }
        }

        model.addAttribute("specDetArr", specDetArr);
        return "page/roadmap-details";
    }

}
