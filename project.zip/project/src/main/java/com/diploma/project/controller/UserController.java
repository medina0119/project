package com.diploma.project.controller;

import com.diploma.project.model.Course;
import com.diploma.project.model.StudentCourse;
import com.diploma.project.model.User;
import com.diploma.project.repository.CourseRepository;
import com.diploma.project.repository.StudentCourseRepository;
import com.diploma.project.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
public class UserController {

    @Autowired
    CourseRepository courseRepository;
    @Autowired
    StudentCourseRepository studentCourseRepository;

    @Autowired
    UserRepo userRepository;

    @GetMapping("/profile")
    public String profile(@AuthenticationPrincipal User user, Map<String, Object> model) {
        User usr = userRepository.findByUsername(user.getUsername());
        List<StudentCourse> studentCourses = (List<StudentCourse>) studentCourseRepository.findAll();
        List<Course> courses = (List<Course>) courseRepository.findAll();
        ArrayList<Course> arrCourses = new ArrayList<>();
        ArrayList<Long> ids = new ArrayList<>();
        for (int i = 0; i < studentCourses.size(); i++) {
            StudentCourse s = studentCourses.get(i);
            System.out.println(s.getAuthorName());
            if (s.getAuthorName().equals(usr.getUsername())) {
                ids.add(s.getCourse_id());
            }
        }
        ids.forEach((n) -> System.out.println(n));
        for (int i = 0; i < courses.size(); i++) {
            Course c = courses.get(i);
            if (ids.contains(c.getId())) {
                arrCourses.add(c);
            }
        }
        model.put("usr", usr);
        model.put("arrCourses", arrCourses);
        return "user/user";
    }

    @GetMapping("/profile/edit")
    public String editProfile(
            @AuthenticationPrincipal User user, Map<String, Object> model
    ) {
        User usr = userRepository.findByUsername(user.getUsername());
        System.out.println(usr.getUsername());
        return "user/edit-profile";
    }
}
