package com.diploma.project.controller;

import com.diploma.project.model.*;
import com.diploma.project.repository.CourseRepository;
import com.diploma.project.repository.PlanRepository;
import com.diploma.project.repository.StudentCourseRepository;
import com.diploma.project.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.lang.reflect.Array;
import java.util.*;

@Controller
public class CourseController {
    @Autowired
    private CourseRepository courseRepository;
    @Autowired
    private StudentCourseRepository studentCourseRepository;
    @Autowired
    private PlanRepository planRepository;

    @Autowired
    private UserRepo userRepository;

    @GetMapping("/courses")
    public String course(Map<String, Object> model){
        Iterable<Course> courses = courseRepository.findAll();
        model.put("courses", courses);
        return "page/courses";
    }

    @PostMapping("/courses")
    public String addCourseStudent(
            @AuthenticationPrincipal User user,
            @RequestParam Long course_id, Map<String, Object> model
    ) {
        StudentCourse studentCourse = new StudentCourse(course_id, 0, 3, 1, user);

        studentCourseRepository.save(studentCourse);
        Iterable<StudentCourse> studentCourses = studentCourseRepository.findAll();
        model.put("studentCourses", studentCourses);

        return "redirect:courses";
    }


    @GetMapping("/courses/{id}")
    public String coursesDetails(@PathVariable(value="id") long id, Model model){
        if(!courseRepository.existsById(id)){
            return "redirect:/courses";
        }
        Optional<Course> course = courseRepository.findById(id);
        ArrayList<Course> coursesArr = new ArrayList<>();
        course.ifPresent(coursesArr::add);
        model.addAttribute("coursesArr", coursesArr);

        Iterable<Plan> plans = planRepository.findAll();
        List<Plan> planTest = planRepository.findAll();
        ArrayList<Plan> planArr = new ArrayList<>();
        for (int i = 0; i < planTest.size(); i++){
            Plan plan = planTest.get(i);
            if (plan.getCourse_id() == id){
                planArr.add(plan);
            }
        }

        model.addAttribute("planArr", planArr);
        //model.addAttribute("plans", plans);
        return "page/courses-details";
    }

    @GetMapping("/course/add")
    public String coursesAdd(Model model){
        return "teaching/course-add";
    }

    @PostMapping("/course/add")
    public String coursesAddDB(@AuthenticationPrincipal User user, @RequestParam String name, @RequestParam String description, @RequestParam int price,
                               @RequestParam int speciality_id, @RequestParam int lectures, @RequestParam String skill, @RequestParam String language,
                               @RequestParam String author, Map<String, Object> model){
        Course course = new Course(name, description, price, speciality_id, lectures, skill, language, author, user);
        courseRepository.save(course);
        return "redirect:/teaching/courses";
    }


    @GetMapping("/teaching/courses")
    public String getTeachingCourses(
            @AuthenticationPrincipal User user, Map<String, Object> model
    ) {
        List<Course> courseList = (List<Course>) courseRepository.findAll();
        ArrayList<Course> courseArr = new ArrayList<>();
        for (int i = 0; i < courseList.size(); i++) {
            Course c = courseList.get(i);
            if (c.getAuthorName().equals(user.getUsername())) {
                courseArr.add(c);

            }
        }
        model.put("courseArr", courseArr);
        return "teaching/teaching-courses";
    }

    @GetMapping("/teaching/courses/{id}")
    public String teachingCoursesDetails(@PathVariable(value="id") long id, Model model){
        if(!courseRepository.existsById(id)){
            return "redirect:/teaching/courses";
        }
        Optional<Course> course = courseRepository.findById(id);
        ArrayList<Course> coursesArr = new ArrayList<>();
        course.ifPresent(coursesArr::add);
        model.addAttribute("coursesArr", coursesArr);

        Iterable<Plan> plans = planRepository.findAll();
        List<Plan> planTest = planRepository.findAll();
        ArrayList<Plan> planArr = new ArrayList<>();
        for (int i = 0; i < planTest.size(); i++){
            Plan plan = planTest.get(i);
            if (plan.getCourse_id() == id){
                planArr.add(plan);
            }
        }

        model.addAttribute("planArr", planArr);
        return "teaching/teaching-courses-details";
    }

    @PostMapping("/plan/add/{id}")
    public String plansAdd(@RequestParam int course_id, Model model){

        model.addAttribute("course_id", course_id);
        return "teaching/plan-add";
    }

    @PostMapping("/plan/add")
    public String coursesAddDB(@RequestParam int course_id, @RequestParam String title, @RequestParam String description, @RequestParam String text, Map<String, Object> model){
        Plan plan = new Plan(course_id, title, description, text);
        System.out.println(course_id + "\n" + title + "\n" + description + "\n" + text);
        planRepository.save(plan);
        return "redirect:/teaching/courses/" + course_id;
    }

}
