package com.diploma.project.model;

import javax.persistence.*;

//@Table(name = "Speciality1")
@Entity
public class Speciality {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private String description;
    private int sphere_id;
    private int level;

    public Speciality(){}

    public Speciality(String name, String description, int sphere_id, int level) {
        this.name = name;
        this.description = description;
        this.sphere_id = sphere_id;
        this.level = level;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getSphere_id() {
        return sphere_id;
    }

    public void setSphere_id(int sphere_id) {
        this.sphere_id = sphere_id;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
}
