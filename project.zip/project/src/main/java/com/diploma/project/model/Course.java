package com.diploma.project.model;

import javax.persistence.*;

@Entity
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private String description;
    private int price;
    private int followers;
    private int speciality_id;
    private int lectures;
    private String skill;
    private String language;
    private String author;
    private float grading;
    private int viewed;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    private User user_id;


    public Course(String name, String description, int price, int followers, int speciality_id, int lectures, String skill, String language, String author, float grading, int viewed, User user) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.followers = followers;
        this.speciality_id = speciality_id;
        this.lectures = lectures;
        this.skill = skill;
        this.language = language;
        this.author = author;
        this.grading = grading;
        this.viewed = viewed;
        this.user_id = user;
    }

    public Course(String name, String description, int price, int speciality_id, int lectures, String skill, String language, String author, User user) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.speciality_id = speciality_id;
        this.lectures = lectures;
        this.skill = skill;
        this.language = language;
        this.author = author;
        this.user_id = user;
    }

    public Course(){}

    public String getAuthorName() {
        return user_id != null ? user_id.getUsername() : "<none>";
    }

    public User getUser_id() {
        return user_id;
    }

    public void setUser_id(User user_id) {
        this.user_id = user_id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getFollowers() {
        return followers;
    }

    public void setFollowers(int followers) {
        this.followers = followers;
    }

    public int getSpeciality_id() {
        return speciality_id;
    }

    public void setSpeciality_id(int speciality_id) {
        this.speciality_id = speciality_id;
    }

    public int getLectures() {
        return lectures;
    }

    public void setLectures(int lectures) {
        this.lectures = lectures;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public float getGrading() {
        return grading;
    }

    public void setGrading(float grading) {
        this.grading = grading;
    }

    public int getViewed() {
        return viewed;
    }

    public void setViewed(int viewed) {
        this.viewed = viewed;
    }
}
