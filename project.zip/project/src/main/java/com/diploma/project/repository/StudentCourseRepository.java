package com.diploma.project.repository;

import com.diploma.project.model.Message;
import com.diploma.project.model.StudentCourse;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface StudentCourseRepository extends CrudRepository<StudentCourse, Long> {

    //List<StudentCourse> findByTag(Long student_id);
}
