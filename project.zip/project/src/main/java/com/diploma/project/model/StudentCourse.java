package com.diploma.project.model;

import javax.persistence.*;

@Entity
public class StudentCourse {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private Long course_id;
    private int grade;
    private int feedback;
    private int status;

//    status: 1 - active
//    status: 0 - not active
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    private User author;

    public StudentCourse(Long course_id, int grade, int feedback, int status, User user) {
        this.course_id = course_id;
        this.grade = grade;
        this.feedback = feedback;
        this.status = status;
        this.author = user;
    }


    public String getAuthorName() {
        return author != null ? author.getUsername() : "<none>";
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }

    public StudentCourse(Long course_id, int grade, int feedback, int status) {
        this.course_id = course_id;
        this.grade = grade;
        this.feedback = feedback;
        this.status = status;
    }

    public StudentCourse() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCourse_id() {
        return course_id;
    }

    public void setCourse_id(Long course_id) {
        this.course_id = course_id;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public int getFeedback() {
        return feedback;
    }

    public void setFeedback(int feedback) {
        this.feedback = feedback;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
