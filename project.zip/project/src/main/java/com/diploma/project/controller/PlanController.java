package com.diploma.project.controller;

import com.diploma.project.model.Comment;
import com.diploma.project.model.News;
import com.diploma.project.model.Student;
import com.diploma.project.repository.CommentRepository;
import org.springframework.ui.Model;
import com.diploma.project.model.Plan;
import com.diploma.project.repository.PlanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
public class PlanController {

    @Autowired
    private PlanRepository planRepository;
    @Autowired
    private CommentRepository commentRepository;

    @GetMapping("/plan/{id}")
    public String planDetails(@PathVariable(value="id") long id, Model model){

        if(!planRepository.existsById(id)){
            return "redirect:/courses";
        }
        Optional<Plan> plan = planRepository.findById(id);
        ArrayList<Plan> newPlan = new ArrayList<>();
        plan.ifPresent(newPlan::add);
        model.addAttribute("newPlan", newPlan);

        List<Comment> comments = (List<Comment>) commentRepository.findAll();
        ArrayList<Comment> commentsArr = new ArrayList<>();
        for (int i = 0; i < comments.size(); i++){
            Comment comment = comments.get(i);
            if (comment.getPlan_id() == id){
                commentsArr.add(comment);
            }
        }
        model.addAttribute("commentsArr", commentsArr);
        return "page/plan";
    }

    @PostMapping("/plan/delete/{id}")
    public String planDelete(@PathVariable(value="id") long id, Model model){
        Plan plan = planRepository.findById(id).orElseThrow();
        int course_id = plan.getCourse_id();
        planRepository.delete(plan);
        return "redirect:/teaching/courses/" + course_id;
    }



}
